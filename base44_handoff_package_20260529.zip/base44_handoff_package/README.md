# Base44 Handoff Package

This package is the curated handoff bundle for rebuilding and operating the AFL player props workflow in Base44.

## What is included

- `docs/`
  - Base44 handoff specifications
  - current bettor-facing reports and settlement notes
- `code/`
  - current Python scoring, refresh, history, settlement, and report-generation logic
  - the focused Base44 parity reference
- `fixtures/`
  - latest sample Odds API and Wheelo inputs
  - latest scored outputs and portfolio selections
- `artifacts/`
  - rendered HTML/PDF outputs useful for UI parity checks

## Suggested reading order

1. `docs/base44_native_aflplayerprops_handoff.md`
2. `docs/base44_betmate_edge_full_build_spec.md`
3. `code/base44_port_reference.py`
4. `code/betmate_edge_refresh_server.py`
5. `code/score_oddsapi_wheelo_props.py`

## Important notes

- This bundle intentionally excludes secrets and local-only tokens.
- `codex_refresh_token.txt` is not included.
- `__pycache__/` content is not included.
- The included fixture files reflect the current workspace state as of 2026-05-29 AEST.

## Handoff goal

Base44 should be able to use this package to:

- understand the product and data model
- reproduce scoring and portfolio logic
- ingest current structured outputs
- compare Base44 behavior against current Python outputs
