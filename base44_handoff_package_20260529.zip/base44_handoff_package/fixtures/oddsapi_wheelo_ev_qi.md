# Odds API + Model Data EV/QI

Source markets: The Odds API + current Model data player pack.
Marks: Odds API returned INVALID_MARKET for player_marks/player_marks_over.

## Availability
- Carlton Blues v Geelong Cats: 10 bookmakers returned for player_afl_fantasy_points_over, player_disposals, player_goals_scored_over, player_tackles_over.
- Sydney Swans v Richmond Tigers: 10 bookmakers returned for player_afl_fantasy_points_over, player_disposals, player_goals_scored_over, player_tackles_over.
- Brisbane Lions v Fremantle Dockers: 10 bookmakers returned for player_afl_fantasy_points_over, player_disposals, player_goals_scored_over, player_tackles_over.
- Western Bulldogs v Collingwood Magpies: 10 bookmakers returned for player_afl_fantasy_points_over, player_disposals, player_goals_scored_over, player_tackles_over.
- Melbourne Demons v Greater Western Sydney Giants: 10 bookmakers returned for player_afl_fantasy_points_over, player_disposals, player_goals_scored_over, player_tackles_over.
- West Coast Eagles v Essendon Bombers: 10 bookmakers returned for player_afl_fantasy_points_over, player_disposals, player_goals_scored_over, player_tackles_over.

## Walters Portfolio Card
Rules: max 10 bets, max 3 goal props, max 1 per player; goals are stake-discounted.

| Signal | Stake | Player | Market | Side | Line | Price | Book | Proj | Prob | EV | QI | AltScore |
|---|---:|---|---|---:|---:|---:|---|---:|---:|---:|---:|---:|
| A_BET | 0.50u | Hayden McLean | Goals | Over | 2.5 | 4.50 | TAB | 3.0 | 70.2% | 216.0% | 95.0 | 1.2907 |
| A_BET | 0.50u | Liam Fawcett | Goals | Over | 1.5 | 4.00 | TAB | 2.1 | 72.1% | 188.5% | 95.0 | 1.1488 |
| A_BET | 0.50u | Noah Roberts-Thomson | Goals | Over | 0.5 | 2.35 | SportsBet | 1.5 | 85.8% | 101.7% | 95.0 | 0.7066 |
| A_BET | 1.00u | Dion Prestia | Disposals | Under | 22.5 | 1.87 | PointsBet (AU) | 17.4 | 78.7% | 47.2% | 93.5 | 0.3761 |
| A_BET | 1.00u | Matthew Johnson | Disposals | Under | 19.5 | 1.77 | PointsBet (AU) | 15.4 | 76.2% | 34.8% | 93.5 | 0.2705 |
| A_BET | 1.00u | Sullivan Robey | Disposals | Under | 20.5 | 1.87 | PointsBet (AU) | 16.7 | 72.7% | 36.0% | 93.5 | 0.2701 |
| A_BET | 1.00u | Tom McCarthy | Disposals | Under | 25.5 | 1.89 | SportsBet | 22.3 | 71.4% | 34.9% | 95.0 | 0.2655 |
| A_BET | 1.00u | Kyle Langford | Disposals | Under | 20.5 | 1.87 | PointsBet (AU) | 17.1 | 72.1% | 34.9% | 93.5 | 0.2604 |
| A_BET | 1.00u | Toby Greene | Disposals | Over | 17.5 | 1.87 | PointsBet (AU) | 20.7 | 70.2% | 31.3% | 93.5 | 0.2286 |
| A_BET | 1.00u | Hugh McCluggage | Disposals | Under | 22.5 | 1.88 | SportsBet | 19.4 | 68.5% | 28.8% | 95.0 | 0.2119 |

## Suppressed A/B Edges
These remain model-positive but were removed by Walters portfolio discipline.
- Scott Pendlebury Goals Over 0.5 @ 3.50 (SportsBet): SUPPRESSED_GOAL_CAP, EV 84.0%, QI 87.0
- Shaun Mannagh Goals Over 1.5 @ 2.15 (Ladbrokes): SUPPRESSED_GOAL_CAP, EV 53.8%, QI 95.0
- Paddy Cross Goals Over 0.5 @ 2.15 (Betr): SUPPRESSED_GOAL_CAP, EV 52.8%, QI 92.0
- Jake Stringer Goals Over 1.5 @ 1.95 (TAB): SUPPRESSED_GOAL_CAP, EV 48.2%, QI 95.0
- Brent Daniels Goals Over 0.5 @ 1.60 (Betr): SUPPRESSED_GOAL_CAP, EV 38.8%, QI 95.0
- Logan Morris Goals Over 1.5 @ 1.62 (Ladbrokes): SUPPRESSED_GOAL_CAP, EV 38.3%, QI 95.0
- Nate Caddy Goals Over 1.5 @ 1.76 (SportsBet): SUPPRESSED_GOAL_CAP, EV 38.7%, QI 95.0
- Sam Cumming Goals Over 0.5 @ 2.85 (Bet Right): SUPPRESSED_GOAL_CAP, EV 55.1%, QI 87.0
- Max Gruzewski Goals Over 1.5 @ 2.40 (Betr): SUPPRESSED_GOAL_CAP, EV 44.2%, QI 95.0
- Josh Treacy Goals Over 1.5 @ 1.60 (SportsBet): SUPPRESSED_GOAL_CAP, EV 32.1%, QI 95.0
- Jye Amiss Goals Over 1.5 @ 1.53 (Ladbrokes): SUPPRESSED_GOAL_CAP, EV 30.6%, QI 95.0
- Kai Lohmann Goals Over 1.5 @ 1.95 (SportsBet): SUPPRESSED_GOAL_CAP, EV 35.0%, QI 94.9
- Angus Anderson Goals Over 0.5 @ 1.82 (SportsBet): SUPPRESSED_GOAL_CAP, EV 33.0%, QI 95.0
- Mitch McGovern Goals Over 1.5 @ 1.96 (SportsBet): SUPPRESSED_GOAL_CAP, EV 34.5%, QI 94.6
- Archie Roberts Disposals Over 30.5 @ 1.80 (PointsBet (AU)): SUPPRESSED_PORTFOLIO_CAP, EV 25.4%, QI 93.1
- Bailey J. Williams Goals Over 0.5 @ 2.15 (PointsBet (AU)): SUPPRESSED_GOAL_CAP, EV 36.0%, QI 93.8
- Charlie Cameron Goals Over 1.5 @ 1.57 (Ladbrokes): SUPPRESSED_GOAL_CAP, EV 27.1%, QI 94.2
- Michael Frederick Goals Over 0.5 @ 1.51 (SportsBet): SUPPRESSED_GOAL_CAP, EV 26.2%, QI 94.4
- Sam Banks Disposals Under 18.5 @ 1.90 (PointsBet (AU)): SUPPRESSED_PORTFOLIO_CAP, EV 26.9%, QI 85.2
- Steely Green Goals Over 0.5 @ 1.69 (Bet Right): SUPPRESSED_GOAL_CAP, EV 26.7%, QI 92.8

## Ladder Notes
- Hayden McLean Goals Over: Over 2.5 @ 4.5 EV 216.0%; Over 1.5 @ 2.15 EV 103.0%; Over 0.5 @ 1.19 EV 17.8%
- Liam Fawcett Goals Over: Over 1.5 @ 4.0 EV 188.5%; Over 0.5 @ 1.48 EV 38.5%
- Noah Roberts-Thomson Goals Over: Over 0.5 @ 2.35 EV 101.7%; Over 1.5 @ 10.0 EV 400.0%
- Matthew Johnson Disposals Under: Under 19.5 @ 1.77 EV 34.8%; Under 18.5 @ 1.84 EV 29.7%

## Signal Counts
- A_BET: 89
- B_BET: 79
- INFO_ONLY: 3118
- LEAN: 46
- NO_MATCH: 155
- PASS: 2905

QI note: `live_qi` is a current-line confidence score derived from Model data support, model edge, market reliability, and book availability. It is not the historical BetMate QI field.
